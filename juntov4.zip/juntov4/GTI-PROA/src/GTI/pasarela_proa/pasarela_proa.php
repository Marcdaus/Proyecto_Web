<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/pasarela_proa.css">
    <title>Pasarela a PROA</title>
</head>
<body>
    <!-- Sección HEADER -->
    <header>
        <?php include('../../headers/Header_GTI/header_gti.html')?>
    </header>
    <!-- Fin de HEADER -->
    <section>
        <div class="container">
            <div class="bienvenido">
                <h2>Bienvenido a</h2>
                <img src="../../img/PROA.PNG" alt="Logo PROA">
            </div>
            <p>
                Ahora podrá acceder a la página de PROA, junto a su LOGIN y su página de inicio para poder probar todas sus funcionalidades actuales.
            </p>
            <p class="duda">En caso de duda o problema, consulte nuestros <a href="../FAQS.php">FAQs</a> o <a href="../Contacto/Contacto.php">contacte</a> con nosotros.
            </p>
            <a href="../../PROA/login_proa/loginproa.php"><button class="btnreg">PROA</button></a>
        </div>
    </section>
</body>
</html>
