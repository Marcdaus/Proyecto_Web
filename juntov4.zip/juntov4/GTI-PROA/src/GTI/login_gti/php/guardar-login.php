<?php
//======================================================================================================================
//                                     AQUÍ EMPIEZA EL CÓDIGO DEL LOGIN (PHP)
//======================================================================================================================
session_start(); // iniciamos la sesión para poder guardar datos del usuario
require_once('../../../conexion_bbdd/MySQL.inc'); // base de datos

// verificar conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$email = $_POST['usuario']; // usuarios
$password = hash('sha256', $_POST['password']); // hash sha-256 contraseñas

// verificar usuario (buscar el la bbdd)
$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    $_SESSION['mensaje_error'] = "Error en la preparación: " . $stmt->error;
    header("Location: ../login.php");
    exit();
}

$stmt->bind_param("s", $email);

// ejecutar y comprobar resultado
if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows === 1) { // usuario existe
        $usuario = $result->fetch_assoc(); // guarda el usuario

        if ($usuario['password'] === $password) { // contraseña correcta// cuenta activa
            $_SESSION['usuario'] = $usuario;
            header("Location: ../../pasarela_proa/pasarela_proa.php");
            exit();
        } else {
                $_SESSION['mensaje_error'] = "Contraseña incorrecta.";
            }
        } else {
            $_SESSION['mensaje_error'] = "No se encontró ninguna cuenta con ese email.";
        }

} else {
    $_SESSION['mensaje_error'] = "Error al verificar credenciales: " . $stmt->error;
}

// cerrar sesión
$stmt->close();
$conn->close();
header("Location: ../login.php");
exit();
?>