<?php
session_start();
//LLama a la BD
require_once('../../../conexion_bbdd/MySQL.inc');

//Reoge las variables del formulario
$email = $_POST['email'];
$password = $_POST['contraseña'];
$encriptada = hash('sha256', $password);
//Hace la consulta
$sql = "SELECT * FROM usuarios WHERE email = ?";

//Prepara la conexión
$stmt = $conn->prepare($sql);

//Comprueba la preparación
if ($stmt === false) {
    die("Error en la preparación: " . $conn->error);
}
//Bindea los parametros
$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();
//Si el resultado guarda un elemento
if ($resultado->num_rows === 1) {
    //Devuelve la siguiente fila del conjunto de resultados
    $usuario = $resultado->fetch_assoc();
    //Si la contraseña introducida es igual a la de la base de datos debe permitir el paso
    if ($encriptada=== $usuario["password"]) {
        //guardamos el email del usuario
        $_SESSION["usuario"] = $usuario["email"];
        //Redirige al siguiente sitio
        header("Location: ../../Calendario/calendario.php");
        exit;
    } else {
        $_SESSION['mensaje_error'] = "Contraseña incorrecta " . $stmt->error;
        header("Location: ../../login_proa/loginproa.php");
        exit;
    }
} else {
    $_SESSION['mensaje_error'] = "No se encontró ninguna cuenta con ese email" . $stmt->error;
    header("Location: ../../login_proa/loginproa.php");
    exit;
}
//Cerrar sesión
$stmt->close();
$conn->close();
?>

