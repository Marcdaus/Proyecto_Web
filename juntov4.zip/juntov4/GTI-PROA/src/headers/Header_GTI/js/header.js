    // Mostrar/ocultar el menú en móvil al hacer clic en la imagen hamburguesa
    document.getElementById("menu-toggle").addEventListener("click", function () {
      document.getElementById("nav").classList.toggle("active");
    });