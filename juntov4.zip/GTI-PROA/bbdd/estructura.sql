-- Eliminar la base de datos si ya existe
DROP DATABASE IF EXISTS proa;

-- Crear la base de datos
CREATE DATABASE proa;

-- Usar la base de datos recién creada
USE proa;

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-05-2025 a las 02:07:56
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
                            `dni` varchar(15) UNIQUE,
                            `nombre` varchar(60) NOT NULL,
                            `apellido1` varchar(60),
                            `apellido2` varchar(60),
                            `email` varchar(254) NOT NULL,
                            `password` varchar(64) NOT NULL,
                            `estado` tinyint(1) NOT NULL DEFAULT 0,
                            `token` varchar(36) DEFAULT NULL,
                            `validez_token` datetime DEFAULT NULL,
                            `rol` VARCHAR(20) NOT NULL DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indices de la tabla `usuarios`
--

ALTER TABLE `usuarios`
    ADD PRIMARY KEY (`email`);

-- insertamos usuarios por defectos 
INSERT INTO usuarios (dni, nombre, apellido1, apellido2, email, password, estado, rol)
VALUES ('01-9218611', 'Lief', 'Simants', 'Dredge', 'l.simdre@epsg.upv.es', SHA2('9218611', 256), 0, 'alumno'),
       ('20864890A', '1', 'villalba', 'meseguer', '1@1', SHA2('1', 256), 0, 'cliente'),
       ('04-1320191', 'Merline', 'Kirdsch', 'Kampshell', 'm.kirkam@epsg.upv.es', SHA2('1320191', 256), 0, 'alumno'),
       ('05-9971924', 'Debora', 'Rawstorne', '', 'd.rawabc@epsg.upv.es', SHA2('9971924', 256), 0, 'alumno'),
       ('60-4525956', 'Kevan', 'Pounds', 'Mainston', 'k.poumai@upv.es', SHA2('4525956', 256), 0, 'profesor'),
       ('64-6055365', 'Luelle', 'Pridmore', 'Starsmeare', 'l.prista@upv.es', SHA2('6055365', 256), 0, 'profesor'),
       ('64-6738133', 'Eolande', 'Merriton', 'Mizzi', 'e.mermiz@upv.es', SHA2('6738133', 256), 0, 'profesor'),
       ('88-1316390', 'Ondrea', 'Brezlaw', 'Sherwill', 'o.breshe@upv.es', SHA2('1316390', 256), 0, 'pas'),
       ('91-1970980', 'Brooke', 'Malimoe', 'Thomerson', 'b.maltho@upv.es', SHA2('1970980', 256), 0, 'pas'),
       (NULL, 'Daniel', 'Palacio', '', 'dapasa@har.upv.es', SHA2('1234', 256), 0, 'cliente'),
       (NULL, 'Jose Luis', 'Gimenez', '', 'jogilo@upvnet.upv.es', SHA2('4567', 256), 0, 'cliente');

--
-- Estructura de tabla para la tabla `contacto`
--
CREATE TABLE contacto (
                            `id` INT AUTO_INCREMENT PRIMARY KEY,
                            `nombre` VARCHAR(100) NOT NULL,
                            `institucion` VARCHAR(100) NOT NULL,
                            `email` VARCHAR(100) NOT NULL,
                            `contenido` TEXT,
                            `fecha` DATE NOT NULL,
                            `hora` TIME NOT NULL
);

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE asignaturas (
                          `id` INT AUTO_INCREMENT PRIMARY KEY,
                          `nombre` VARCHAR(100) NOT NULL
);
-- insertamos asignaturas por defecto
INSERT INTO asignaturas (nombre) VALUES ('Programación'),('Álgebra'),('Física'),('Proyecto Web'),('Ingles'),('Electrónica'),('Redes'),('CDIO');
--
-- Estructura de tabla para la tabla `matrículas`
--

CREATE TABLE matriculas (
                            `id` INT AUTO_INCREMENT PRIMARY KEY,
                            `dni` VARCHAR(100) NOT NULL,
                            `id_asignatura` INT NOT NULL,
                            FOREIGN KEY (`dni`) REFERENCES usuarios(`dni`),
                            FOREIGN KEY (`id_asignatura`) REFERENCES asignaturas(id)
);

-- insertamos usuarios por defectos

-- Lief Simants Dredge
INSERT INTO matriculas (dni, id_asignatura) VALUES
('01-9218611', 1), -- Programación
('01-9218611', 2), -- Álgebra
('01-9218611', 3); -- Física

-- Merline Kirdsch Kampshell
INSERT INTO matriculas (dni, id_asignatura) VALUES
('04-1320191', 2), -- Álgebra
('04-1320191', 4), -- Proyecto Web
('04-1320191', 5); -- Inglés

-- Debora Rawstorne
INSERT INTO matriculas (dni, id_asignatura) VALUES
('05-9971924', 1), -- Programación
('05-9971924', 5), -- Inglés
('05-9971924', 6); -- Electrónica

--
-- Índices para tablas volcadas
--



--
-- AUTO_INCREMENT de las tablas volcadas
--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
