<?php
session_start();
require_once('../../../conexion_bbdd/MySQL.inc');

// Obtener la fecha y la hora actual 
$fecha = date("Y-m-d"); 
$hora = date("H:i:s");  

// Preparar la sentencia SQL
$sql = "INSERT INTO contacto (nombre, institucion, email, contenido, fecha, hora) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
  die("Error en la preparación: " . $conn->error);
}

$stmt->bind_param("ssssss", $_POST['nombre'], $_POST['institucion'], $_POST['email'], $_POST['contenido'], $fecha, $hora);

// Ejecutar y comprobar resultado
if ($stmt->execute()) {
   $_SESSION['mensaje_valido'] = "Formulario enviado correctamente.";
} else {
   $_SESSION['mensaje_error'] = "Error al enviar los datos a la base de datos: " . $stmt->error;
}

// Cerrar conexión
$stmt->close();
$conn->close();
header("Location: ../Contacto.php");
?>