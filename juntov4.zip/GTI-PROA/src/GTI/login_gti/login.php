
<!--==================================================================================================================================  
                                     AQUI EMPIEZA EL CÓDIGO DEL LOGIN (HTML)
===================================================================================================================================-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=2">
    <link rel="stylesheet" href="./css/estilo_login.css">
    <title>Login</title>
    <style>
    </style>
</head>
<body>
    <header>
        <!-- Sección HEADER -->
        <?php include('../../headers/Header_GTI/header_gti.html')?>
        <!--Fin de HEADER -->
    </header>

    <!-- Fin de HEADER -->
    <!-- Caja principal del formulario de login -->
    <div class="cajas">
    <main class="Caja_login">

        <!-- incluimos los errores -->
        <?php
             include('../../errores/errores.php');
        ?>
        
        <h2>Bienvenido de nuevo</h2>

        <!-- Formulario de inicio de sesión -->
        <form id="login" method="POST" action="./php/guardar-login.php">
            <!-- Campo para introducir el email -->
            <label for="email">Email </label>
            <input id="email" type="email" name="usuario" placeholder="Introduzca su email" required autofocus>

            <!-- Campo para introducir la contraseña -->
            <label for="password">Contraseña </label>
            <input id="password" type="password" name="password" placeholder="Introduzca su contraseña" required>

            <!-- Botón para enviar el formulario -->
            <input class="btnlog" type="submit" value="Login">
        </form>
    </main>

    <!-- Texto con informacion para registrarse -->
    <article class="Caja_registro">
        <h2>En caso de que no tengas cuenta</h2>
        <!-- Botón que redirige a la página de registro -->
        <a  href="../Registro_GTI/registro_gti.php"><button class="btnreg">Registrarse</button></a>
    </article>
    </div>
</body>
</html>

