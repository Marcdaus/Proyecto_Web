<?php
session_start();
$mensaje_valido = '';
$mensaje_error = '';
//comprueba  la variable mensaje
if (isset($_SESSION['mensaje_valido'])) {// comprueba que existe y que no este vacia
    $mensaje_valido = $_SESSION['mensaje_valido'];
    unset($_SESSION['mensaje_valido']);// lo borra una vez se ha utilizado
}
// hacemos lo mismo para la otra variable
if (isset($_SESSION['mensaje_error'])) {
    $mensaje_error = $_SESSION['mensaje_error'];
    unset($_SESSION['mensaje_error']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/GTI-PROA/src/errores/css/errores.css">
    <title></title>
</head>
<body>

<!-- Mostrar el mensaje de error si existe -->

<!-- Contenedor centrado -->
<div class="contenedor_mensaje">
    <!-- Mostrar mensajes validos -->
    <?php if (!empty($mensaje_valido)): ?>
        <div class="mensaje_valido">
            <img src="/GTI-PROA/src/img/check.png" alt="Check verde">
            <?php echo $mensaje_valido; ?>
        </div>
    <?php endif; ?>
     <!-- Mostrar el mensaje de error  -->
    <?php if (!empty($mensaje_error)): ?>
        <div class="mensaje_error">
            <img src="/GTI-PROA/src/img/wrong.png" alt="Cruz roja">
            <?php echo $mensaje_error; ?>
        </div>
    <?php endif; ?>
</div>

</body>
</html>

