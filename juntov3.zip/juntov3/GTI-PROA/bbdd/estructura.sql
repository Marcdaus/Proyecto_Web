-- Eliminar la base de datos si ya existe
DROP DATABASE IF EXISTS proa;

-- Crear la base de datos
CREATE DATABASE proa;

-- Usar la base de datos recién creada
USE proa;

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 20-05-2025 a las 02:07:56
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
                            `dni` int(9) UNIQUE,
                            `nombre` varchar(60) NOT NULL,
                            `apellidos` varchar(60),
                            `email` varchar(254) NOT NULL,
                            `password` varchar(64) NOT NULL,
                            `estado` tinyint(1) NOT NULL DEFAULT 0,
                            `token` varchar(36) DEFAULT NULL,
                            `validez_token` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
--
-- Estructura de tabla para la tabla `contacto`
--
CREATE TABLE contacto (
                            `id` INT AUTO_INCREMENT PRIMARY KEY,
                            `nombre` VARCHAR(100) NOT NULL,
                            `institucion` VARCHAR(100) NOT NULL,
                            `email` VARCHAR(100) NOT NULL,
                            `contenido` TEXT,
                            `fecha` DATE NOT NULL,
                            `hora` TIME NOT NULL
);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
    ADD PRIMARY KEY (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
