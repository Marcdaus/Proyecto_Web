<?php
//==================================================================================================================================
//                                AQUÍ EMPIEZA EL CÓDIGO DEL REGISTRO DE GTI (PHP)
//==================================================================================================================================

session_start(); // Iniciamos la sesión para poder guardar datos del usuario

require_once('../../conexion_bbdd/MySQL.inc'); // Llama a la base de datos

// Verifica la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$sql_check = "SELECT email FROM usuarios WHERE email = ? ";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("s", $_POST['email'] );
$stmt_check->execute();
$stmt_check->store_result();

if ($stmt_check->num_rows > 0) {
    die("El email ya está registrado.");//Añadir error
}
$stmt_check->close();

// Preparar la sentencia SQL
$sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error en la preparación: " . $conn->error);
}

// Bindear los parámetros
$stmt->bind_param("sss", $_POST['usuario'], $_POST['email'], $_POST['password']);

//Comprueba si las variables están vacías
if(empty($_POST['email'])){
    die("Todos los email son obligatorios.");
}
if(empty( $_POST['password'])){
    die("Todos los password son obligatorios.");
}

if (empty($_POST['usuario'])) {
    die("Todos los name son obligatorios.");
}

// Ejecutar y comprobar resultado
if ($stmt->execute()) {
    $_SESSION['mensaje_valido'] = "Registrado correctamente.";
} else {
    $_SESSION['mensaje_error'] = "Error al enviar los datos a la base de datos: " . $stmt->error;
}

//Cerrar sesión
$stmt->close();
$conn->close();
header("Location: ../../index.php");
?>

