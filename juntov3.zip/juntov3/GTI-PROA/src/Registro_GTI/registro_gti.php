
<!--==================================================================================================================================  
                                     AQUI EMPIEZA EL CÓDIGO DEL LOGIN (HTML)
===================================================================================================================================-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0 maximum-scale=2">
    <link rel="stylesheet" href="./css/registro_gti.css">
    <title>Registro</title>
    <style>
    </style>
</head>
<body>
    <!-- Sección HEADER -->
    <?php include('../header_gti.html')?>

    <!--Fin de HEADER -->
    <!-- incluimos los errores -->
    <?php
     include('../errores/errores.php');
    ?>


    <!--Fin de HEADER -->
    <!-- Caja principal del formulario de login -->
    <div class="cajas">
    <!-- Texto con información para registrarse -->
   
    <article class="Caja_registro">
        <h2>En caso de que ya tengas una cuenta</h2>
        
        <!-- Botón que redirige a la página de registro -->
        <a  href="./login.php"><button class="btnreg">LOGIN</button></a>
    </article>
     <!-- Login-->
    <main class="Caja_login">
        <h2>Bienvenido/a</h2>

        <!-- Mostramos el mensaje de error si existe -->
        <?php if (!empty($error)) echo "<div class='errores'>$error</div>"; ?>

        <!-- Formulario de inicio de sesión -->
        <form id="login" method="POST" action="./php/guardar-registro.php">

            <!-- Campo para introducir el institución -->
            <label for="name">Nombre de la institución </label>
            <input id="name" type="text" name="usuario" placeholder="Introduzca el nombre de su Institución" required autofocus>
            
            <!-- Campo para introducir el email -->
            <label for="email">Email </label>
            <input id="email" type="email" name="email" placeholder="Introduzca su email" required autofocus>
            
            <!-- Campo para introducir la contraseña -->
            <label for="password">Contraseña </label>
            <input id="password" type="password" name="password" placeholder="Introduzca su contraseña" required>

            <!-- Botón para enviar el formulario -->
            
            <input class="btnlog" type="submit" value="Login">
        </form>
    </main>
    </div>
</body>
</html>

