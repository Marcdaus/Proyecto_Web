<!-- ========================================================================================================
                                     CÓDIGO HTML PARA logear USUARIOS PROA
======================================================================================================== -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login/PROA</title>
    <link rel="stylesheet" href="css/login_proa.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="js/registro.js" defer ></script>
</head>
<body>
<section id="login">
    <!-- titulo y tecto de la empresa -->



    <!--  fin titulo y tecto de la empresa -->
    <div class="div_login">
        <h1 class="titulo1_blanco">Logueate en nuestros módulos</h1>
        <h1 class="titulo1_negro">LOGIN</h1>


<!-- FORMULARIO 1: CREDENCIALES -->
<!-- el formulario comprueba si la variable mostrando_form esta en true y si lo esta le asigna un active a la clase del formulario -->
<!-- onsubmit="event.preventDefault(); validarCredenciales();"> esto sirve para que el formulario no se envie y refreseque la pantalla ademas de ejecutar la función-->
<form id="login_credenciales" class="formulario" action="./php/usuario-login-proa.php" method="POST">
    <div id="erroresJS" class="errores"></div>
    
    <!-- inputs de credenciales que guardan medianet php lo escrito es decir si voy al formulario 1 escribo al
     y luego del formulario 2 vuelvo a el uno el formulario 1 contendra lo escrito antes gracias a las variables de php-->
 
    <label class="texto_input" for="email">Introduzca su email</label> 
    <input id="email" name="email" type="email" placeholder="email">

    
    <label class="texto_input" for="contraseña">Introduzca una contraseña</label> 
    <input id="contraseña" name="contraseña" type="password" placeholder="contraseña">
 
    <div class = "botones">
        <input type="submit" value="enviar">
    </div>
</form>
<!-- FIN FORMULARIO 1: CREDENCIALES -->
    </div>
</section>
</body>
</html>
