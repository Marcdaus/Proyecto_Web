<?php
session_start();
require_once('../../conexion_bbdd/MySQL.inc');

$email = $_POST['email'];
$password = $_POST['contraseña'];

$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error en la preparación: " . $conn->error);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();

if ($resultado->num_rows === 1) {
    $usuario = $resultado->fetch_assoc();
    if (password_verify($password, $usuario["password"])) {
        $_SESSION["usuario"] = $usuario["email"];
        header("Location: calendario.php");
        exit;
    } else {
        echo "Contraseña incorrecta.";
    }
} else {
    echo "No se encontró una cuenta con ese email.";
}
?>
